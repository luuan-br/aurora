module.exports = {
  apps: [
    {
      name: "remix-app-kits-aurora",
      script: "node",
      args: "./node_modules/@remix-run/serve/dist/cli.js ./build/server/index.js",
      env: {
        PORT: 4002,
        NODE_ENV: "production",
      },
      watch: false,
      instances: 1,
      exec_mode: "fork"
    },
  ],
};
