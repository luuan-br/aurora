import {
  reactExtension,
  useApi,
  BlockStack,
  Text,
  InlineStack,
  Box,
  Image,
  MoneyField,
} from '@shopify/ui-extensions-react/admin';
import { useState, useEffect } from 'react';

// The target used here must match the target used in the extension's toml file (./shopify.extension.toml)
export default reactExtension('admin.product-details.configuration.render', () => <App />);

function App() {
  const { extension: { target }, i18n } = useApi<'admin.product-details.configuration.render'>();
  const product = useProduct();

  console.log('product', product);

  return (
    <BlockStack gap>
      <Text>
        {i18n.translate('welcome', { target })}
      </Text>

      {product?.variants.map((variant) => (
        <BlockStack key={variant.id} gap>
          <InlineStack>
            <Text>Variante: {variant.title}</Text>
          </InlineStack>

          {variant.productVariantComponents.map((item) =>
            <InlineStack key={item.id} gap >
              <Box
                maxInlineSize={50}
                maxBlockSize={50}
              >
                <Image
                  alt={``}
                  source={
                    item.imageUrl ||
                    'https://cdn.shopify.com/s/files/1/0701/2240/6073/files/placeholder-image.png?v=1747680996'
                  }
                />
              </Box>

              <Text fontWeight='bold-200'>{item.product.title}</Text>
              <MoneyField label='' value={item.price} readOnly={true} currencyCode='BRL' />
            </InlineStack>
          )}

        </BlockStack>
      ))}
    </BlockStack>
  );
}

function useProduct() {
  const { data, query } = useApi<'admin.product-details.configuration.render'>();
  const productId = (data as any)?.selected[0].id;
  const [product, setProduct] = useState<{
    id: string;
    title: string;
    bundleComponents: {
      id: string;
      title: string;
    }[];
    variants: {
      id: string;
      title: string;
      productVariantComponents: {
        id: string;
        title: string;
        price: number;
        imageUrl?: string;
        product: {
          title: string
        }
      }[]
    }[]
  }>(null);

  console.log('productId', productId);

  useEffect(() => {
    if (!productId) return;

    query(
      `#graphql
      query GetProduct($id: ID!) {
        product(id: $id) {
          id
          title
          variants(first: 100) {
            nodes {
              id
              title
              productVariantComponents(first: 100) {
                nodes {
                  productVariant {
                    id
                    title
                    price
                    image {
                      url
                    }
                    product {
                      title
                    }
                  }
                }
              }
            }
          }
          bundleComponents(first: 100) {
            nodes {
              componentProduct {
                id
                title
              }
            }
          }
        }
      }
      `,
      { variables: { id: productId } }
    ).then(({ data, errors }) => {
      if (errors) {
        console.error(errors);
      } else {
        const { bundleComponents, variants, ...product } = (data as {
          product: {
            id: string;
            title: string;
            bundleComponents: {
              nodes: {
                componentProduct: {
                  id: string;
                  title: string;
                }
              }[]
            }
            variants: {
              nodes: Array<{
                id: string;
                title: string;
                productVariantComponents: {
                  nodes: Array<{
                    productVariant: {
                      id: string;
                      title: string;
                      price: number;
                      image?: {
                        url: string;
                      }
                      product: {
                        title: string
                      }
                    }
                  }>
                }
              }>
            }
          }
        }).product;

        setProduct({
          ...product,
          variants: variants.nodes.map(({ productVariantComponents, ...variant }) => ({
            ...variant,
            productVariantComponents: productVariantComponents.nodes.map(({ productVariant }) => ({
              ...productVariant,
              imageUrl: productVariant.image?.url || null,
            }))
          })),
          bundleComponents: bundleComponents.nodes.map(({ componentProduct }) => ({
            ...componentProduct
          }))
        })
      }
    })
  }, [productId, query]);

  return product;
}
