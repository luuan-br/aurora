# Product Configuration Extension

The Product Configuration extensions let app developers build custom functionality at defined points in
the Product Details and Product Variant Details sections of the Shopify Admin experience. 
You can learn more about Product Configuration extensions in Shopify’s [developer documentation](https://shopify.dev/docs/apps/selling-strategies/bundles/product-config).
