export interface Product {
  [x: string]: any;
  id: string;
  variantId: string;
  productId: string;
  productImage?: string;
  productAlt: string;
  productTitle: string;
  variantTitle: string;
  quantity: number;
  options?: {
    name: string;
    value: string;
  }[];
  price?: string;
}

export interface BundleVariant {
  id: number;
  optionName: string;
  optionValue: string;
  products: Product[];
}


export interface Metafield {
  key: string;
  namespace: string;
  value: string;
  type: string;
}

export interface MetaobjectField {
  key: string;
  value: string;
}

export interface Metaobject {
  id: string;
  type: string;
  fields: MetaobjectField[];
}

export interface ParentProductData {
  title: string;
  handle: string;
  description: string;
  metafields: Metafield[];
  metaobjects: Metaobject[];
}

export interface BundleProduct {
  id: string;
  title: string;
  status: string;
  featuredImage?: {
    url: string;
    altText: string;
  };
  variantsCount: number;
  createdAt: string;
  totalInventory: number;
}

export type LoaderSuccess = {
  bundles: BundleProduct[];
  pageInfo: {
    hasNextPage: boolean;
    hasPreviousPage: boolean;
    startCursor: string | null;
    endCursor: string | null;
  };
  direction: "forward" | "reverse";
};

export type LoaderError = {
  error: string;
};

export type LoaderData = LoaderSuccess | LoaderError;
