import {
  Page,
  Card,
  Layout,
  BlockStack,
  Text,
  InlineStack,
  Thumbnail,
  Button,
  Badge,
  EmptyState,
  IndexTable,
  Modal,
  Box,
} from "@shopify/polaris";
import { useCallback, useState } from "react";
import { json, type LoaderFunctionArgs, type ActionFunctionArgs } from "@remix-run/node";
import { useLoaderData, Link, useNavigate, useSubmit } from "@remix-run/react";
import { authenticate } from "../shopify.server";
import type { BundleProduct } from "app/@types/intex";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin } = await authenticate.admin(request);

  const url = new URL(request.url);
  const after = url.searchParams.get("after");
  const before = url.searchParams.get("before");
  const direction = before ? "reverse" : "forward";

  const paginationArgs = before
    ? { last: 10, before } // paginação reversa
    : { first: 10, after }; // paginação normal

  const query = `
    query GetBundleProducts($first: Int, $last: Int, $after: String, $before: String) {
      products(
        query: "product_type:Bundle"
        first: $first
        last: $last
        after: $after
        before: $before
        sortKey: CREATED_AT
        reverse: true
      ) {
        pageInfo {
          hasNextPage
          hasPreviousPage
          startCursor
          endCursor
        }
        edges {
          cursor
          node {
            id
            title
            status
            featuredImage {
              url
              altText
            }
            variants(first: 10) {
              edges {
                node {
                  inventoryQuantity
                }
              }
            }
            createdAt
            totalVariants
          }
        }
      }
    }
  `;

  try {
    const response = await admin.graphql(query, {
      variables: {
        ...paginationArgs,
      },
    });

    const data = await response.json();

    const bundles: BundleProduct[] = data.data.products.edges.map((edge: any) => {
      const node = edge.node;
      let totalInventory = 0;

      if (node.variants?.edges) {
        totalInventory = node.variants.edges.reduce(
          (sum: number, variantEdge: any) => sum + (variantEdge.node.inventoryQuantity || 0),
          0
        );
      }

      return {
        id: node.id,
        title: node.title,
        status: node.status,
        featuredImage: node.featuredImage,
        variantsCount: node.totalVariants,
        createdAt: node.createdAt,
        totalInventory,
      };
    });

    const pageInfo = data.data.products.pageInfo;

    return json({
      bundles,
      pageInfo: {
        hasNextPage: pageInfo.hasNextPage,
        hasPreviousPage: pageInfo.hasPreviousPage,
        startCursor: pageInfo.startCursor,
        endCursor: pageInfo.endCursor,
      },
      direction,
    });
  } catch (error) {
    console.error("Error loading bundles:", error);
    return json({ error: "Failed to load bundles" }, { status: 500 });
  }
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const formData = await request.formData();
  const productId = formData.get("productId");

  if (typeof productId !== "string") {
    return json({ error: "ID inválido" }, { status: 400 });
  }

  try {
    const response = await admin.graphql(
      `#graphql
      mutation DeleteProduct($input: ProductDeleteInput!) {
        productDelete(input: $input) {
          deletedProductId
          userErrors {
            field
            message
          }
        }
      }
    `,
      {
        variables: {
          input: {
            id: productId,
          },
        },
      }
    );

    const result = await response.json();

    if (result.data.productDelete.userErrors.length > 0) {
      return json({ error: result.data.productDelete.userErrors[0].message }, { status: 400 });
    }

    return json({ success: true });
  } catch (error) {
    console.error("Erro ao excluir o produto:", error);
    return json({ error: "Erro ao excluir o produto" }, { status: 500 });
  }
};

export default function BundlesListPage() {
  const { bundles, error, pageInfo } = useLoaderData<any>();
  const navigate = useNavigate();
  const submit = useSubmit();

  const [selectedToDelete, setSelectedToDelete] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);

  const handleViewBundle = useCallback(
    (id: string) => navigate(`/app/bundles/${id.replace("gid://shopify/Product/", "")}`),
    [navigate]
  );

  const handleOpenModal = useCallback((id: string) => {
    setSelectedToDelete(id);
    setShowModal(true);
  }, []);

  const handleConfirmDelete = useCallback(() => {
    if (!selectedToDelete) return;

    const formData = new FormData();
    formData.append("productId", selectedToDelete);

    submit(formData, {
      method: "post",
    });

    setShowModal(false);
  }, [selectedToDelete, submit]);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  };

  const truncateTitle = (title: string) => {
    if (title.length <= 36) return title;
    return `${title.substring(0, 36
    )}...`;
  };

  const rowMarkup = bundles?.map((bundle: any, index: any) => (
    <IndexTable.Row id={bundle.id} key={bundle.id} position={index}>
      <IndexTable.Cell>
        <InlineStack gap="200" align="start">
          <Box width="60px">
            <Thumbnail
              source={bundle.featuredImage?.url || "https://cdn.shopify.com/s/files/1/0533/2089/files/placeholder-images-product-1_large.png"}
              alt={bundle.featuredImage?.altText || "Bundle product"}
              size="small"
            />
          </Box>
         <BlockStack gap="300" align="center">

            <Link
              to={`/app/bundles/${bundle.id.replace("gid://shopify/Product/", "")}`}
              style={{ textDecoration: "none", color: "black" }}
            >
              <Text variant="bodyMd" fontWeight="bold" as="span" truncate>
                {truncateTitle(bundle.title)}
              </Text>
            </Link>
         </BlockStack>
        </InlineStack>
      </IndexTable.Cell>
      <IndexTable.Cell>
        <Badge tone={bundle.status === "ACTIVE" ? "success" : "warning"}>
          {bundle.status === "ACTIVE" ? "Ativo" : "Rascunho"}
        </Badge>
      </IndexTable.Cell>
      <IndexTable.Cell>{bundle.variantsCount} variações</IndexTable.Cell>
      <IndexTable.Cell>{bundle.totalInventory} em estoque</IndexTable.Cell>
      <IndexTable.Cell>{formatDate(bundle.createdAt)}</IndexTable.Cell>
      <IndexTable.Cell>
        <InlineStack gap="200">
          <Button onClick={() => handleViewBundle(bundle.id)}>Ver</Button>
          <Button tone="critical" onClick={() => handleOpenModal(bundle.id)}>
            Excluir
          </Button>
        </InlineStack>
      </IndexTable.Cell>
    </IndexTable.Row>
  ));

  if (error) {
    return (
      <Page title="Pacotes" backAction={{ url: "/app" }}>
        <Layout>
          <Layout.Section>
            <Card>
              <Text as="p" variant="bodyMd">Erro ao carregar pacotes.</Text>
            </Card>
          </Layout.Section>
        </Layout>
      </Page>
    );
  }

  if (!bundles || bundles.length === 0) {
    return (
      <Page title="Pacotes" backAction={{ url: "/app" }}>
        <BlockStack gap="400">
          <EmptyState
            heading="Nenhum pacote criado ainda"
            action={{
              content: "Criar primeiro pacote",
              url: "/app/bundles/new",
            }}
            image="https://cdn.shopify.com/s/files/1/0262/4071/2726/files/emptystate-files.png"
          >
            <p>Crie pacotes de produtos para oferecer combinações especiais aos seus clientes.</p>
          </EmptyState>
        </BlockStack>
      </Page>
    );
  }

  return (
    <Page
      title="Pacotes Criados"
      backAction={{ url: "/app" }}
      primaryAction={{
        content: "Criar novo pacote",
        url: "/app/bundles/new",
      }}
    >
      <BlockStack gap="400">
        <Card>
          <IndexTable
            resourceName={{ singular: "pacote", plural: "pacotes" }}
            itemCount={bundles.length}
            headings={[
              { title: "Nome" },
              { title: "Status" },
              { title: "Variações" },
              { title: "Estoque" },
              { title: "Criado em" },
              { title: "Ações" },
            ]}
            selectable={false}
            pagination={{
              hasNext: pageInfo.hasNextPage,
              hasPrevious: pageInfo.hasPreviousPage,
              onNext: () => {
                navigate(`/app?after=${pageInfo.endCursor}`);
              },
              onPrevious: () => {
                navigate(`/app?before=${pageInfo.startCursor}`);
              },
            }}
          >
            {rowMarkup}
          </IndexTable>
        </Card>
      </BlockStack>

      <Modal
        open={showModal}
        onClose={() => setShowModal(false)}
        title="Excluir pacote"
        primaryAction={{
          content: "Excluir",
          onAction: handleConfirmDelete,
          destructive: true,
        }}
        secondaryActions={[
          {
            content: "Cancelar",
            onAction: () => setShowModal(false),
          },
        ]}
      >
        <Modal.Section>
          <Text as="p">Tem certeza que deseja excluir este pacote? Esta ação não pode ser desfeita.</Text>
        </Modal.Section>
      </Modal>
    </Page>
  );
}