import {
  Page,
  Card,
  FormLayout,
  TextField,
  Layout,
  BlockStack,
  PageActions,
  Box,
  Button,
  Divider,
  InlineStack,
  Thumbnail,
  ActionList,
  Popover,
  Text,
  Banner,
  Select,
  Checkbox,
} from "@shopify/polaris";
import {
  PlusCircleIcon,
  DeleteIcon,
  DuplicateIcon,
  ImageIcon,
} from "@shopify/polaris-icons";
import { useCallback, useState, useEffect, useMemo } from "react";
import { authenticate } from "../shopify.server";
import { json } from "@remix-run/node";
import { useSubmit, useActionData, useNavigation, useLoaderData } from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import type { BundleVariant, Metaobject, ParentProductData, Product } from "app/@types/intex";

async function updateProductMetafields(
  admin: any,
  productId: string,
  variants: BundleVariant[]
) {
  try {
    // Fetch complete parent product data for each variant
    const productData = await Promise.all(
      variants.flatMap(v =>
        v.products.map(async p => {
          // Get parent product details
          const productResponse = await admin.graphql(
            `#graphql
            query GetProduct($id: ID!) {
              product(id: $id) {
                title
                description
                handle
                metafields(first: 50) {
                  edges {
                    node {
                      key
                      namespace
                      value
                      type
                    }
                  }
                }
              }
            }`,
            { variables: { id: p.productId } }
          );

          const productResult = await productResponse.json();
          const product = productResult.data.product;

          // Get metaobjects associated with the product
          let metaobjects: Metaobject[] = [];
          try {
            const metaobjectsResponse = await admin.graphql(
              `#graphql
              query GetProductMetaobjects($id: ID!) {
                product(id: $id) {
                  metaobjects(first: 10) {
                    edges {
                      node {
                        id
                        type
                        fields {
                          key
                          value
                        }
                      }
                    }
                  }
                }
              }`,
              { variables: { id: p.productId } }
            );

            const metaobjectsResult = await metaobjectsResponse.json();

            metaobjects = metaobjectsResult.data.product.metaobjects.edges.map((e: any) => ({
              id: e.node.id,
              type: e.node.type,
              fields: e.node.fields.map((f: any) => ({
                key: f.key,
                value: f.value
              }))
            }));
          } catch (error) {
            console.error("Error fetching metaobjects:", error);
          }

          return {
            variantId: p.variantId,
            parentProduct: {
              title: product.title,
              description: product.description,
              handle: product.handle,
              metafields: product.metafields.edges.map((e: any) => ({
                key: e.node.key,
                namespace: e.node.namespace,
                value: e.node.value,
                type: e.node.type
              })),
              metaobjects: metaobjects
            } as ParentProductData
          };
        })
      )
    );

    const metafieldValue = variants.map(variant => ({
      optionName: variant.optionName,
      optionValue: variant.optionValue,
      products: variant.products.map(product => {
        const parentData = productData.find(pt => pt.variantId === product.variantId)?.parentProduct || {
          title: '',
          handle: '',
          description: '',
          metafields: [],
          metaobjects: []
        } as ParentProductData;

        return {
          variantId: product.variantId,
          productId: product.productId,
          quantity: product.quantity,
          title: product.productTitle,
          variantTitle: product.variantTitle,
          handle: product.handle,
          price: product.price,
          image: product.productImage,
          parentProduct: parentData
        };
      })
    }));

    const response = await admin.graphql(
      `#graphql
      mutation SetMetafield($input: MetafieldsSetInput!) {
        metafieldsSet(metafields: [$input]) {
          metafields {
            id
            key
            namespace
            value
          }
          userErrors {
            field
            message
            code
          }
        }
      }`,
      {
        variables: {
          input: {
            ownerId: productId,
            namespace: "bundle",
            key: "components",
            type: "json",
            value: JSON.stringify(metafieldValue)
          }
        }
      }
    );

    const result = await response.json();

    if (result.data?.metafieldsSet?.userErrors?.length) {
      console.error("Erro ao salvar metafield:", result.data.metafieldsSet.userErrors);
      throw new Error(result.data.metafieldsSet.userErrors[0].message);
    }

    return true;
  } catch (error) {
    console.error("Erro ao atualizar metafields:", error);
    throw error;
  }
}

export const action = async ({ request }: { request: Request }) => {
  const formData = await request.formData();
  const { admin } = await authenticate.admin(request);

  const productId = formData.get("productId") as string;
  const title = formData.get("title") as string;
  const variantsRaw = formData.get("variants") as string;
  const useMagicPrice = formData.get("useMagicPrice") === "on";

  if (!productId || !title || !variantsRaw) {
    return json({ error: "Dados incompletos" }, { status: 400 });
  }

  let variants;
  try {
    variants = JSON.parse(variantsRaw);
  } catch (err) {
    return json({ error: "Formato de variantes inválido", details: (err as Error).message }, { status: 400 });
  }

  try {
    // --- Monta o payload para productSet (atualiza ou cria) ---
    const optionName = variants[0].optionName;
    const optionValues = variants.map((v: any) => ({ name: v.optionValue }));

    const formattedVariants = variants.map((v: any) => {
      const sumPrice = v.products.reduce((sum: number, p: any) => sum + parseFloat(p.price) * p.quantity, 0);
      const finalPrice = useMagicPrice ? Math.round(sumPrice) : sumPrice;
      return {
        optionValues: [{ optionName, name: v.optionValue }],
        price: finalPrice
      };
    });

    const productSetResp = await admin.graphql(
      `#graphql
      mutation UpsertBundle($input: ProductSetInput!, $sync: Boolean!) {
        productSet(input: $input, synchronous: $sync) {
          product {
            id
            title
            variants(first: 100) {
              edges {
                node {
                  id
                  title
                  sku
                  price
                }
              }
            }
          }
          productSetOperation {
            id
            status
            userErrors {
              code
              field
              message
            }
          }
          userErrors {
            code
            field
            message
          }
        }
      }
      `,
      {
        variables: {
          input: {
            id: productId,
            title,
            productOptions: [{ name: optionName, position: 1, values: optionValues }],
            variants: formattedVariants,
            productType: "Bundle",
            status: "ACTIVE",
          },
          sync: true
        }
      }
    );
    
    const productSetJson = await productSetResp.json();
    const setErrors = productSetJson.data.productSet.userErrors;
    if (setErrors.length) {
      console.error("productSet Errors:", setErrors);
      return json({ error: "Falha no productSet", details: setErrors }, { status: 400 });
    }

    const metafieldResp = await admin.graphql(
      `#graphql
      mutation SetProductMagicPrice($input: MetafieldsSetInput!) {
        metafieldsSet(metafields: [$input]) {
          metafields {
            id
            key
            namespace
            value
          }
          userErrors {
            field
            message
            code
          }
        }
      }`,
      {
        variables: {
          input: {
            ownerId: productId,
            namespace: "custom",
            key: "use_magic_price",
            type: "boolean",
            value: useMagicPrice.toString()
          }
        }
      }
    );

    const metafieldJson = await metafieldResp.json();
    if (metafieldJson.data?.metafieldsSet?.userErrors?.length) {
      console.error("Metafield Error:", metafieldJson.data.metafieldsSet.userErrors);
      return json({ error: "Erro ao atualizar o metafield use_magic_price" }, { status: 400 });
    }

    // --- Atualiza relacionamentos dos componentes do bundle com priceInput customizado ---
    const bundleProduct = productSetJson.data.productSet.product;
    const relationships = variants.map((v: any, idx: number) => {
      // calcula soma original dos componentes
      const sumPrice = v.products.reduce((sum: number, p: any) => sum + parseFloat(p.price) * p.quantity, 0);
      // arredonda para inteiro mais próximo e subtrai R$0,01 se ativado
      const roundedPrice = useMagicPrice ? Math.floor(sumPrice) - 0.01 : undefined;

      return {
        parentProductVariantId: bundleProduct.variants.edges[idx].node.id,
        removeAllProductVariantRelationships: true,
        productVariantRelationshipsToCreate: v.products.map((p: any) => ({ id: p.variantId, quantity: p.quantity })),
        ...(useMagicPrice && {
          priceInput: {
            calculation: "FIXED",
            price: parseFloat(roundedPrice!.toFixed(2))
          }
        })
      };
    });

    const bundleResp = await admin.graphql(
      `#graphql
      mutation UpdateBundleComponents($input: [ProductVariantRelationshipUpdateInput!]!) {
        productVariantRelationshipBulkUpdate(input: $input) {
          userErrors { field message }
        }
      }
      `,
      { variables: { input: relationships } }
    );
    const bundleJson = await bundleResp.json();
    const bundleErrors = bundleJson.data.productVariantRelationshipBulkUpdate.userErrors;
    if (bundleErrors.length) {
      console.error("Bundle Relationship Errors:", bundleErrors);
      return json({ error: "Falha ao atualizar componentes do pacote", details: bundleErrors }, { status: 400 });
    }

    // Salvar metafields com as variantes do pacote
    await updateProductMetafields(admin, productId, variants);

    // --- Publica no canal Online Store ---
    const pubsResp = await admin.graphql(
      `#graphql
      query GetPublications { publications(first: 10) { edges { node { id name } } } }
      `
    );
    const pubsJson: any = await pubsResp.json();
    if (pubsJson.errors) {
      console.error("Publications Query Errors:", pubsJson.errors);
      return json({ error: "Falha ao buscar canais de publicação", details: pubsJson.errors }, { status: 500 });
    }
    const online = pubsJson.data.publications.edges.map((e: any) => e.node).find((c: any) => c.name === "Online Store");
    if (!online) {
      return json({ error: "Canal 'Online Store' não encontrado." }, { status: 500 });
    }

    const publishResp = await admin.graphql(
      `#graphql
      mutation Publish($id: ID!, $pubId: ID!) {
        publishablePublish(id: $id, input: { publicationId: $pubId }) {
          userErrors { field message }
        }
      }
      `,
      { variables: { id: bundleProduct.id, pubId: online.id } }
    );
    const publishJson = await publishResp.json();
    const publishErrors = publishJson.data.publishablePublish.userErrors;
    if (publishErrors.length) {
      console.error("Publish Errors:", publishErrors);
      return json({ error: "Falha ao publicar produto", details: publishErrors }, { status: 400 });
    }

    return json({ success: true, productId: bundleProduct.id });
  } catch (err) {
    console.error("Unexpected Error:", err);
    return json({ error: "Erro interno ao atualizar bundle", details: (err as Error).message }, { status: 500 });
  }
};

export const loader = async ({
  params,
  request
}: LoaderFunctionArgs) => {
  const { admin } = await authenticate.admin(request);

  const response = await admin.graphql(
    `#graphql
    query GetProduct($id: ID!) {
      product(id: $id) {
        id
        title
        options {
          id
          name
          optionValues {
            id
            name
          }
        }
        variants(first: 100) {
          nodes {
            id
            title
            price
            selectedOptions {
              name
              value
            }
            image {
              url
              altText
            }
            productVariantComponents(first: 100) {
              nodes {
                quantity
                productVariant {
                  id
                  title
                  price
                  image {
                    url
                    altText
                  }
                  product {
                    id
                    title
                  }
                }
              }
            }
          }
        }
        metafield(namespace: "custom", key: "use_magic_price") {
          value
        }
      }
    }`,
    {
      variables: {
        id: `gid://shopify/Product/${params.productId}`,
      },
    },
  );
  const responseJson = await response.json();

  return { product: responseJson.data?.product ?? null };
};

export default function EditBundlesPage() {
  const { product } = useLoaderData<typeof loader>();
  const [title, setTitle] = useState<string>(() => product.title ?? "");
  const lockedOptionName = product.options?.[0]?.name ?? "Cor";
  const initialVariants = useMemo<BundleVariant[]>(() => {
    return product.variants.nodes.map((v: any) => ({
      id: v.id,
      optionName: lockedOptionName,
      optionValue: v.title,
      products: v.productVariantComponents.nodes.map((c: any) => ({
        id: c.productVariant.id,
        variantId: String(c.productVariant.id),
        productId: String(c.productVariant.product.id),
        productImage: c.productVariant.image?.url || null, // Usando imagem da variante
        productAlt: c.productVariant.image?.altText || c.productVariant.title || "",
        productTitle: c.productVariant.product.title,
        variantTitle: c.productVariant.title,
        quantity: c.quantity,
        price: c.productVariant.price,
        options: v.selectedOptions,
      })),
    }));
  }, [product, lockedOptionName]);
  const [variants, setVariants] = useState<BundleVariant[]>(initialVariants);
  const [popoverState, setPopoverState] = useState<Record<string, boolean>>({});
  const [useMagicPrice, setUseMagicPrice] = useState<boolean>(() => {
    return product?.metafield?.value === "true" ? true : false
  });
  const actionData: any = useActionData();
  const [success, setSuccess] = useState<any>(false);
  const [error, setError] = useState<any>(null);
  const navigation = useNavigation();
  const isSubmitting = navigation.state === "submitting";

  const variantOptions = [
    { label: "Cor", value: "Cor" },
    { label: "Tamanho", value: "Tamanho" },
    { label: "Material", value: "Material" },
    { label: "Personalização", value: "Personalização" },
  ];

  useEffect(() => {
    if (actionData?.error) {
      setError(actionData.error);
    } else if (actionData?.success) {
      setSuccess(true);
    }
  }, [actionData]);

  const handleOptionNameChange = useCallback((variantId: number, value: string) => {
    if (value !== lockedOptionName) {
      setError(`Todas as variantes devem ter o tipo "${lockedOptionName}".`);
      return;
    }
    setVariants(prev =>
      prev.map(v => v.id === variantId ? { ...v, optionName: value } : v)
    );
  }, [lockedOptionName]);

  const handleOptionValueChange = useCallback(
    (variantId: number, value: string) => {
      setVariants(prev =>
        prev.map(v => (v.id === variantId ? { ...v, optionValue: value } : v))
      );
    },
    []
  );

  const addVariant = useCallback(() => {
    setVariants(prev => [
      ...prev,
      {
        id: Date.now(),
        optionName: lockedOptionName || "Cor",
        optionValue: "",
        products: []
      },
    ]);
  }, [lockedOptionName]);

  const removeVariant = useCallback((variantId: number) => {
    setVariants(prev => {
      const newVariants = prev.filter(v => v.id !== variantId);

      return newVariants;
    });
  }, []);

  const selectProducts = useCallback(async (variantId: number) => {
    const result = await window.shopify.resourcePicker({
      type: "variant",
      action: "select",
      multiple: true,
      filter: {
        archived: false,
        draft: false,
        hidden: false,
        query: "NOT product_type:Bundle"
      }
    });
    if (!result?.selection) return;

    const selected: Product[] = result.selection.map((v: any) => ({
      id: `${v.product.id}-${v.id}`,
      variantId: v.id,
      productId: v.product.id,
      productImage: v.image?.url || null, // Usando imagem da variante
      productAlt: v.image?.altText || v.title || "",
      productTitle: v.product.title,
      variantTitle: v.title,
      quantity: 1,
      price: v.price,
      options: v.selectedOptions,
    }));

    setVariants(prev =>
      prev.map(v => {
        if (v.id !== variantId) return v;
        const existingIds = new Set(v.products.map(p => p.id));
        const newProducts = selected.filter(p => !existingIds.has(p.id));
        return { ...v, products: [...v.products, ...newProducts] };
      })
    );
  }, []);

  const removeProduct = useCallback((variantId: number, productId: string) => {
    setVariants(prev =>
      prev.map(v =>
        v.id === variantId
          ? { ...v, products: v.products.filter(p => p.id !== productId) }
          : v
      )
    );
  }, []);

  const duplicateProduct = useCallback(
    (variantId: number, product: Product) => {
      setVariants(prev =>
        prev.map(v => {
          if (v.id !== variantId) return v;
          const copy: Product = {
            ...product,
            id: `${product.id}-dup-${Date.now()}`,
          };
          const idx = v.products.findIndex(p => p.id === product.id);
          const list = [...v.products];
          list.splice(idx + 1, 0, copy);
          return { ...v, products: list };
        })
      );
    },
    []
  );

  const togglePopover = useCallback((key: string) => {
    setPopoverState(prev => ({ ...prev, [key]: !prev[key] }));
  }, []);

  const updateQuantity = useCallback(
    (variantId: number, productId: string, qty: number) => {
      if (qty < 1) {
        removeProduct(variantId, productId);
        return;
      }

      setVariants(prev =>
        prev.map(v => {
          if (v.id !== variantId) return v;
          return {
            ...v,
            products: v.products.map(p =>
              p.id === productId ? { ...p, quantity: qty } : p
            ),
          };
        })
      );
    },
    [removeProduct]
  );

  const submit = useSubmit();

  const handleSave = () => {
    // Reset errors
    setError(null);

    // Validate form
    if (!title.trim()) {
      setError("Por favor, insira um título para o pacote");
      return;
    }

    if (variants.some(v => !v.optionName.trim())) {
      setError("Por favor, selecione um tipo para todas as variantes");
      return;
    }

    if (variants.some(v => !v.optionValue.trim())) {
      setError("Por favor, insira um valor para todas as variantes");
      return;
    }

    if (variants.some(v => v.products.length === 0)) {
      setError("Por favor, adicione pelo menos um produto para cada variante");
      return;
    }

    // Validate variant IDs
    const hasInvalidIds = variants.some(v =>
      v.products.some(p => !p.variantId || typeof p.variantId !== 'string')
    );

    if (hasInvalidIds) {
      setError("Algumas variantes têm IDs inválidos");
      return;
    }

    // Prepare form data
    const formData = new FormData();
    formData.append("productId", product.id)
    formData.append("title", title);
    formData.append("variants", JSON.stringify(variants));
    formData.append("useMagicPrice", useMagicPrice ? "on" : "off");

    submit(formData, { method: "post" });
  };

  return (
    <Page title="Editar pacote" backAction={{ url: "/app" }} narrowWidth>
      <Layout>
        <Layout.Section>
          <BlockStack gap={"300"}>
            {success && (
              <Banner
                title="Pacote editado com sucesso!"
                tone="success"
                onDismiss={() => setSuccess(false)}
              />
            )}

            {error && (
              <Banner
                title={error}
                tone="critical"
                onDismiss={() => setError(null)}
              />
            )}

            <Card>
              <FormLayout>
                <TextField
                  type="text"
                  label="Título do pacote"
                  value={title}
                  onChange={setTitle}
                  autoComplete="off"
                  requiredIndicator
                />
              </FormLayout>
            </Card>

            <Card>
              <BlockStack gap="300" align="start">
                <Text as="h2" variant="headingSm">
                  Variantes do pacote
                </Text>

                <Box
                  background="bg-surface"
                  borderColor="border"
                  borderWidth="025"
                  borderRadius="200"
                >
                  {variants.map((variant, idx) => (
                    <BlockStack key={variant.id} gap="0">
                      <Box padding={"300"}>
                        <BlockStack gap="300" align="center">
                          <InlineStack
                            gap="200"
                            blockAlign="end"
                            align="space-between"
                          >
                            <div style={{ flex: 1 }}>
                              <InlineStack gap="200">
                                <div style={{ flex: 1 }}>
                                  <Select
                                    label="Tipo da variante"
                                    options={variantOptions}
                                    value={variant.optionName}
                                    onChange={(v) => handleOptionNameChange(variant.id, v)}
                                    disabled={lockedOptionName !== null}
                                  />
                                </div>
                                <div style={{ flex: 1 }}>
                                  <TextField
                                    label="Valor da variante"
                                    placeholder={`ex: ${variant.optionName === "Cor" ? "Preto" : variant.optionName === "Tamanho" ? "GG" : "Valor"}`}
                                    value={variant.optionValue}
                                    onChange={(v) => handleOptionValueChange(variant.id, v)}
                                    autoComplete="off"
                                    requiredIndicator
                                  />
                                </div>
                              </InlineStack>
                            </div>

                            {variants.length > 1 && (
                              <Button
                                icon={DeleteIcon}
                                onClick={() => removeVariant(variant.id)}
                                accessibilityLabel="Remover variante"
                              />
                            )}
                          </InlineStack>

                          {variant.products.length === 0 && (
                            <BlockStack gap="100" align="center">
                              <Text as="p" variant="headingSm">
                                Selecione as variantes de produto para esta opção
                              </Text>

                              <Button
                                variant="primary"
                                onClick={() => selectProducts(variant.id)}
                              >
                                Selecionar Variantes
                              </Button>
                            </BlockStack>
                          )}

                          {variant.products.length !== 0 && (
                            <BlockStack gap="100" align="center">
                              <InlineStack
                                gap="200"
                                blockAlign="end"
                                align="space-between"
                              >
                                <Text as="p" variant="headingSm">
                                  Variantes de produto nesta opção
                                </Text>

                                <Button
                                  variant="plain"
                                  onClick={() => selectProducts(variant.id)}
                                >
                                  Adicionar Mais Variantes
                                </Button>
                              </InlineStack>

                              <BlockStack gap="200" align="center">
                                {variant.products.map((product) => {
                                  const key = `${variant.id}-${product.id}`;
                                  return (
                                    <BlockStack gap="200" key={product.id}>
                                      <Divider />

                                      <InlineStack
                                        blockAlign="center"
                                        gap="500"
                                      >
                                        <Thumbnail
                                          source={product.productImage || ImageIcon}
                                          alt={product.productAlt}
                                        />

                                        <div style={{ flex: 1 }}>
                                          <Text
                                            as="span"
                                            variant="headingMd"
                                            fontWeight="semibold"
                                          >
                                            {product.productTitle}
                                          </Text>

                                          {product.options?.map((opt, i) => (
                                            <Text key={i} as="p" variant="bodySm">
                                              {opt.name} {opt.value}
                                            </Text>
                                          ))}

                                          {product.price && (
                                            <Text as="p" variant="bodySm">
                                              Preço: R$ {parseFloat(product.price).toFixed(2)}
                                            </Text>
                                          )}
                                        </div>

                                        <InlineStack
                                          gap="200"
                                          align="end"
                                          blockAlign="end"
                                        >
                                          <div style={{ flex: 1 }}>
                                            <TextField
                                              label="Quantidade"
                                              type="number"
                                              value={String(product.quantity)}
                                              onChange={(v) =>
                                                updateQuantity(
                                                  variant.id,
                                                  product.id,
                                                  Number(v)
                                                )
                                              }
                                              autoComplete="off"
                                              min={1}
                                            />
                                          </div>

                                          <Popover
                                            active={Boolean(popoverState[key])}
                                            activator={
                                              <Button
                                                disclosure
                                                onClick={() =>
                                                  togglePopover(key)
                                                }
                                              >
                                                Ações
                                              </Button>
                                            }
                                            onClose={() => togglePopover(key)}
                                          >
                                            <ActionList
                                              actionRole="menuitem"
                                              items={[
                                                {
                                                  content: "Remover",
                                                  icon: DeleteIcon,
                                                  onAction: () =>
                                                    removeProduct(
                                                      variant.id,
                                                      product.id
                                                    ),
                                                },
                                                {
                                                  content: "Duplicar",
                                                  icon: DuplicateIcon,
                                                  onAction: () =>
                                                    duplicateProduct(
                                                      variant.id,
                                                      product
                                                    ),
                                                },
                                              ]}
                                            />
                                          </Popover>
                                        </InlineStack>
                                      </InlineStack>
                                    </BlockStack>
                                  );
                                })}
                              </BlockStack>
                            </BlockStack>
                          )}
                        </BlockStack>
                      </Box>

                      {idx === variants.length - 1 && (
                        <Box>
                          <Divider />
                          <Box padding={"100"}>
                            <Button
                              icon={PlusCircleIcon}
                              variant="tertiary"
                              fullWidth={false}
                              onClick={addVariant}
                            >
                              Adicionar outra variante
                            </Button>
                          </Box>
                        </Box>
                      )}
                    </BlockStack>
                  ))}
                </Box>
              </BlockStack>
            </Card>

            <Card>
              <FormLayout>
                <Checkbox
                  label="Arredondar preço para valor promocional (ex: R$ 110,00 para R$ 109,99)"
                  checked={useMagicPrice}
                  onChange={(checked) => setUseMagicPrice(checked)}
                />
                <Text as="p" variant="bodySm" tone="subdued">
                  Quando ativado, o preço do pacote será arredondado para o valor promocional mais próximo.
                </Text>
              </FormLayout>
            </Card>

            {success && (
              <Banner
                title="Pacote editado com sucesso!"
                tone="success"
                onDismiss={() => setSuccess(false)}
              />
            )}

            {error && (
              <Banner
                title={error}
                tone="critical"
                onDismiss={() => setError(null)}
              />
            )}
          </BlockStack>
        </Layout.Section>
      </Layout>

      <PageActions
        primaryAction={{
          content: 'Salvar',
          onAction: handleSave,
          disabled: isSubmitting,
        }}
      />
    </Page>
  );
}