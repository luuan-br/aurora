import {
  Page,
  Card,
  FormLayout,
  TextField,
  Layout,
  BlockStack,
  PageActions,
  Box,
  Button,
  Divider,
  InlineStack,
  Thumbnail,
  ActionList,
  Popover,
  Text,
  Banner,
  Select,
  Checkbox,
} from "@shopify/polaris";
import {
  PlusCircleIcon,
  DeleteIcon,
  DuplicateIcon,
  ImageIcon,
} from "@shopify/polaris-icons";
import { useCallback, useState, useEffect } from "react";
import { authenticate } from "../shopify.server";
import { json } from "@remix-run/node";
import { useSubmit, useActionData, useNavigation } from "@remix-run/react";
import type { BundleVariant, Metaobject, ParentProductData, Product } from "app/@types/intex";

async function updateProductMetafields(
  admin: any,
  productId: string,
  variants: BundleVariant[]
) {
  try {
    // Fetch complete parent product data for each variant
    const productData = await Promise.all(
      variants.flatMap(v =>
        v.products.map(async p => {
          // Get parent product details
          const productResponse = await admin.graphql(
            `#graphql
            query GetProduct($id: ID!) {
              product(id: $id) {
                title
                description
                handle
                metafields(first: 50) {
                  edges {
                    node {
                      key
                      namespace
                      value
                      type
                    }
                  }
                }
              }
            }`,
            { variables: { id: p.productId } }
          );
          const productResult = await productResponse.json();
          const product = productResult.data.product;

          // Get metaobjects associated with the product
          let metaobjects: Metaobject[] = [];
          try {
            const metaobjectsResponse = await admin.graphql(
              `#graphql
              query GetProductMetaobjects($id: ID!) {
                product(id: $id) {
                  metaobjects(first: 10) {
                    edges {
                      node {
                        id
                        type
                        fields {
                          key
                          value
                        }
                      }
                    }
                  }
                }
              }`,
              { variables: { id: p.productId } }
            );
            const metaobjectsResult = await metaobjectsResponse.json();
            metaobjects = metaobjectsResult.data.product.metaobjects.edges.map((e: any) => ({
              id: e.node.id,
              type: e.node.type,
              fields: e.node.fields.map((f: any) => ({
                key: f.key,
                value: f.value
              }))
            }));
          } catch (error) {
            console.error("Error fetching metaobjects:", error);
          }

          return {
            variantId: p.variantId,
            parentProduct: {
              title: product.title,
              description: product.description,
              handle: product.handle,
              metafields: product.metafields.edges.map((e: any) => ({
                key: e.node.key,
                namespace: e.node.namespace,
                value: e.node.value,
                type: e.node.type
              })),
              metaobjects: metaobjects
            } as ParentProductData
          };
        })
      )
    );

    const metafieldValue = variants.map(variant => ({
      optionName: variant.optionName,
      optionValue: variant.optionValue,
      products: variant.products.map(product => {
        const parentData = productData.find(pt => pt.variantId === product.variantId)?.parentProduct || {
          title: '',
          handle: '',
          description: '',
          metafields: [],
          metaobjects: []
        } as ParentProductData;

        return {
          variantId: product.variantId,
          productId: product.productId,
          quantity: product.quantity,
          title: product.productTitle,
          variantTitle: product.variantTitle,
          handle: product.handle,
          price: product.price,
          image: product.productImage,
          parentProduct: parentData
        };
      })
    }));

    const response = await admin.graphql(
      `#graphql
      mutation SetMetafield($input: MetafieldsSetInput!) {
        metafieldsSet(metafields: [$input]) {
          metafields {
            id
            key
            namespace
            value
          }
          userErrors {
            field
            message
            code
          }
        }
      }`,
      {
        variables: {
          input: {
            ownerId: productId,
            namespace: "bundle",
            key: "components",
            type: "json",
            value: JSON.stringify(metafieldValue)
          }
        }
      }
    );

    const result = await response.json();

    if (result.data?.metafieldsSet?.userErrors?.length) {
      console.error("Erro ao salvar metafield:", result.data.metafieldsSet.userErrors);
      throw new Error(result.data.metafieldsSet.userErrors[0].message);
    }

    return true;
  } catch (error) {
    console.error("Erro ao atualizar metafields:", error);
    throw error;
  }
}

export const action = async ({ request }: { request: Request }) => {
  const formData = await request.formData();
  const { admin } = await authenticate.admin(request);

  const title = formData.get("title") as string;
  const variantsRaw = formData.get("variants") as string;
  const useMagicPrice = formData.get("useMagicPrice") === "on";

  if (!title || !variantsRaw) {
    return json({ error: "Dados incompletos" }, { status: 400 });
  }

  let variants: BundleVariant[];

  try {
    variants = JSON.parse(variantsRaw);
  } catch (e) {
    return json({ error: "Formato de variantes inválido" }, { status: 400 });
  }

  try {
    const optionName = variants[0].optionName;
    const optionValues = variants.map((v: any) => ({ name: v.optionValue }));

    const formattedVariants = variants.map((v: any) => {
      const sumPrice = v.products.reduce((sum: number, p: any) => sum + parseFloat(p.price) * p.quantity, 0);
      const finalPrice = useMagicPrice ? Math.round(sumPrice) : sumPrice;

      return {
        optionValues: [{ optionName, name: v.optionValue }],
        price: finalPrice
      };
    });

    const response = await admin.graphql(
      `#graphql
      mutation createProductAsynchronous($productSet: ProductSetInput!, $synchronous: Boolean!) {
        productSet(synchronous: $synchronous, input: $productSet) {
          product {
            id
            title
            variants(first: 10) {
              edges {
                node {
                  id
                  title
                  sku
                  price
                }
              }
            }
          }
          productSetOperation {
            id
            status
            userErrors {
              code
              field
              message
            }
          }
          userErrors {
            code
            field
            message
          }
        }
      }`,
      {
        variables: {
          productSet: {
            title,
            productOptions: [{
              name: optionName,
              position: 1,
              values: optionValues
            }],
            variants: formattedVariants,
            productType: "Bundle",
            status: "ACTIVE",
            metafields: [
              {
                namespace: "custom",
                key: "use_magic_price",
                type: "boolean",
                value: useMagicPrice.toString()
              }
            ]
          },
          synchronous: true
        }
      }
    );

    const result = await response.json();

    if (result.data?.productSet?.userErrors?.length) {
      return json({ error: result.data.productSet.userErrors[0].message }, { status: 400 });
    }

    const productId = result.data?.productSet?.product?.id;

    if (!productId) {
      return json({ error: "Falha ao obter ID do produto criado" }, { status: 400 });
    }

    await admin.graphql(
      `#graphql
      mutation($id: ID!) {
        publishablePublishToCurrentChannel(id: $id) {
          publishable {
            availablePublicationsCount { count }
            resourcePublicationsCount  { count }
          }
          userErrors {
            field
            message
          }
        }
      }`,
      {
        variables: { id: productId }
      }
    );

    const productVariants = result.data?.productSet?.product?.variants?.edges || [];

    if (productVariants.length !== variants.length) {
      return json({ error: "Número de variantes criadas não corresponde ao esperado" }, { status: 400 });
    }

    const formatVariantId = (id: string) => {
      if (id.startsWith('gid://')) {
        return id;
      }

      return `gid://shopify/ProductVariant/${id}`;
    };

    const variantRelationships = productVariants.map((variantNode: any, index: number) => {
      const variantProducts = variants[index].products;
      // calcula soma original dos componentes
      const sumPrice = variantProducts.reduce((sum: number, p: any) => sum + parseFloat(p.price) * p.quantity, 0);
      // arredonda para inteiro mais próximo e subtrai R$0,01 se ativado
      const roundedPrice = useMagicPrice ? Math.floor(sumPrice) - 0.01 : undefined;

      return {
        parentProductVariantId: variantNode.node.id,
        productVariantRelationshipsToCreate: variantProducts.map(product => ({
          id: formatVariantId(product.variantId),
          quantity: product.quantity
        })),
        removeAllProductVariantRelationships: true,
        ...(useMagicPrice && {
          priceInput: {
            calculation: "FIXED",
            price: parseFloat(roundedPrice!.toFixed(2))
          }
        })
      };
    });

    const responseBundle = await admin.graphql(
      `#graphql
      mutation CreateBundleComponents($input: [ProductVariantRelationshipUpdateInput!]!) {
        productVariantRelationshipBulkUpdate(input: $input) {
          parentProductVariants {
            id
            productVariantComponents(first: 10) {
              nodes {
                id
                quantity
                productVariant {
                  id
                  title
                }
              }
            }
          }
          userErrors {
            code
            field
            message
          }
        }
      }`,
      {
        variables: {
          input: variantRelationships
        }
      }
    );

    const bundleResult = await responseBundle.json();

    if (bundleResult.data?.productVariantRelationshipBulkUpdate?.userErrors?.length) {
      return json({
        error: bundleResult.data.productVariantRelationshipBulkUpdate.userErrors[0].message
      }, { status: 400 });
    }

    // Salvar metafields com as variantes do pacote
    await updateProductMetafields(admin, productId, variants);

    const pubsResponse = await admin.graphql(
      `#graphql
      query GetOnlineStorePublication {
        publications(first: 10) {
          edges {
            node {
              id
              name
            }
          }
        }
      }`
    );

    const pubsData = await pubsResponse.json();

    const onlinePub = pubsData.data.publications.edges
      .map((e: any) => e.node)
      .find((pub: any) => pub.name === "Online Store");
    if (!onlinePub) {
      return json({ error: "Não foi possível encontrar o canal 'Loja Virtual'." }, { status: 500 });
    }

    const publicationId = onlinePub.id;

    const publishResponse = await admin.graphql(
      `#graphql
      mutation PublishToOnlineStore($productId: ID!, $publicationId: ID!) {
        publishablePublish(id: $productId, input: { publicationId: $publicationId }) {
          publishable {
            publishedOnPublication(publicationId: $publicationId)
          }
          userErrors {
            field
            message
          }
        }
      }`,
      {
        variables: { productId, publicationId }
      }
    );

    const publishResult = await publishResponse.json();

    if (publishResult.data.publishablePublish.userErrors.length) {
      return json(
        { error: publishResult.data.publishablePublish.userErrors[0].message },
        { status: 400 }
      );
    }

    return json({
      success: true,
      productId,
    });

  } catch (error) {
    console.error("Erro ao criar produto:", error);
    return json({ error: `Ocorreu um erro ao criar o produto.` }, { status: 500 });
  }
};

export default function NewBundlesPage() {
  const [title, setTitle] = useState<string>("");
  const [variants, setVariants] = useState<BundleVariant[]>([
    {
      id: Date.now(),
      optionName: "Cor",
      optionValue: "",
      products: []
    },
  ]);
  const [lockedOptionName, setLockedOptionName] = useState<string | null>(null);
  const [popoverState, setPopoverState] = useState<Record<string, boolean>>({});
  const [useMagicPrice, setUseMagicPrice] = useState<boolean>(false);
  const actionData: any = useActionData();
  const [success, setSuccess] = useState<any>(false);
  const [error, setError] = useState<any>(null);
  const navigation = useNavigation();
  const isSubmitting = navigation.state === "submitting";

  const variantOptions = [
    { label: "Cor", value: "Cor" },
    { label: "Tamanho", value: "Tamanho" },
    { label: "Material", value: "Material" },
    { label: "Personalização", value: "Personalização" },
  ];

  useEffect(() => {
    if (actionData?.error) {
      setError(actionData.error);
    } else if (actionData?.success) {
      setSuccess(true);
      setTitle("");
      setVariants([
        {
          id: Date.now(),
          optionName: "Cor",
          optionValue: "",
          products: []
        },
      ]);
      setLockedOptionName(null);
    }
  }, [actionData]);

  const handleOptionNameChange = useCallback(
    (variantId: number, value: string) => {
      const firstOptionName = variants[0].optionName;
      if (variantId !== variants[0].id && value !== firstOptionName) {
        setError(`Todas as variantes devem ter o tipo "${firstOptionName}".`);
        return;
      }

      setVariants((prev) =>
        prev.map((v) => (v.id === variantId ? { ...v, optionName: value } : v))
      );
    },
    [variants]
  );

  const handleOptionValueChange = useCallback(
    (variantId: number, value: string) => {
      setVariants(prev =>
        prev.map(v => (v.id === variantId ? { ...v, optionValue: value } : v))
      );
    },
    []
  );

  const addVariant = useCallback(() => {
    setVariants(prev => [
      ...prev,
      {
        id: Date.now(),
        optionName: lockedOptionName || "Cor",
        optionValue: "",
        products: []
      },
    ]);
  }, [lockedOptionName]);

  const removeVariant = useCallback((variantId: number) => {
    setVariants(prev => {
      const newVariants = prev.filter(v => v.id !== variantId);
      if (newVariants.length === 0) {
        setLockedOptionName(null);
      }
      return newVariants;
    });
  }, []);

  const selectProducts = useCallback(async (variantId: number) => {
    const result = await window.shopify.resourcePicker({
      type: "variant",
      action: "select",
      multiple: true,
      filter: {
        archived: false,
        draft: false,
        hidden: false,
        query: "NOT product_type:Bundle"
      }
    });

    if (!result?.selection) return;

    const selected: Product[] = result.selection.map((v: any) => ({
      id: `${v.product.id}-${v.id}`,
      variantId: v.id,
      productId: v.product.id,
      productImage: v.image?.originalSrc,
      productAlt: v.title,
      productTitle: v.product.title,
      variantTitle: v.title,
      quantity: 1,
      price: v.price,
      options: v.selectedOptions,
    }));

    setVariants(prev =>
      prev.map(v => {
        if (v.id !== variantId) return v;
        const existingIds = new Set(v.products.map(p => p.id));
        const newProducts = selected.filter(p => !existingIds.has(p.id));
        return { ...v, products: [...v.products, ...newProducts] };
      })
    );
  }, []);

  const removeProduct = useCallback((variantId: number, productId: string) => {
    setVariants(prev =>
      prev.map(v =>
        v.id === variantId
          ? { ...v, products: v.products.filter(p => p.id !== productId) }
          : v
      )
    );
  }, []);

  const duplicateProduct = useCallback(
    (variantId: number, product: Product) => {
      setVariants(prev =>
        prev.map(v => {
          if (v.id !== variantId) return v;
          const copy: Product = {
            ...product,
            id: `${product.id}-dup-${Date.now()}`,
          };
          const idx = v.products.findIndex(p => p.id === product.id);
          const list = [...v.products];
          list.splice(idx + 1, 0, copy);
          return { ...v, products: list };
        })
      );
    },
    []
  );

  const togglePopover = useCallback((key: string) => {
    setPopoverState(prev => ({ ...prev, [key]: !prev[key] }));
  }, []);

  const updateQuantity = useCallback(
    (variantId: number, productId: string, qty: number) => {
      if (qty < 1) {
        removeProduct(variantId, productId);
        return;
      }

      setVariants(prev =>
        prev.map(v => {
          if (v.id !== variantId) return v;
          return {
            ...v,
            products: v.products.map(p =>
              p.id === productId ? { ...p, quantity: qty } : p
            ),
          };
        })
      );
    },
    [removeProduct]
  );

  const submit = useSubmit();

  const handleSave = () => {
    setError(null);

    if (!title.trim()) {
      setError("Por favor, insira um título para o pacote");
      return;
    }

    if (variants.some(v => !v.optionName.trim())) {
      setError("Por favor, selecione um tipo para todas as variantes");
      return;
    }

    if (variants.some(v => !v.optionValue.trim())) {
      setError("Por favor, insira um valor para todas as variantes");
      return;
    }

    if (variants.some(v => v.products.length === 0)) {
      setError("Por favor, adicione pelo menos um produto para cada variante");
      return;
    }

    const hasInvalidIds = variants.some(v =>
      v.products.some(p => !p.variantId || typeof p.variantId !== 'string')
    );

    if (hasInvalidIds) {
      setError("Algumas variantes têm IDs inválidos");
      return;
    }

    const formData = new FormData();
    formData.append("title", title);
    formData.append("variants", JSON.stringify(variants));
    formData.append("useMagicPrice", useMagicPrice ? "on" : "off");

    submit(formData, { method: "post" });
  };

  return (
    <Page title="Criar pacote" backAction={{ url: "/app" }} narrowWidth>
      <Layout>
        <Layout.Section>
          <BlockStack gap={"300"}>
            {success && (
              <Banner
                title="Pacote criado com sucesso!"
                tone="success"
                onDismiss={() => setSuccess(false)}
              />
            )}

            {error && (
              <Banner
                title={error}
                tone="critical"
                onDismiss={() => setError(null)}
              />
            )}

            <Card>
              <FormLayout>
                <TextField
                  type="text"
                  label="Título do pacote"
                  value={title}
                  onChange={setTitle}
                  autoComplete="off"
                  requiredIndicator
                />
              </FormLayout>
            </Card>

            <Card>
              <BlockStack gap="300" align="start">
                <Text as="h2" variant="headingSm">
                  Variantes do pacote
                </Text>

                <Box
                  background="bg-surface"
                  borderColor="border"
                  borderWidth="025"
                  borderRadius="200"
                >
                  {variants.map((variant, idx) => (
                    <BlockStack key={variant.id} gap="0">
                      <Box padding={"300"}>
                        <BlockStack gap="300" align="center">
                          <InlineStack
                            gap="200"
                            blockAlign="end"
                            align="space-between"
                          >
                            <div style={{ flex: 1 }}>
                              <InlineStack gap="200">
                                <div style={{ flex: 1 }}>
                                  <Select
                                    label="Tipo da variante"
                                    options={variantOptions}
                                    value={variant.optionName}
                                    onChange={(v) => handleOptionNameChange(variant.id, v)}
                                    disabled={lockedOptionName !== null}
                                  />
                                </div>
                                <div style={{ flex: 1 }}>
                                  <TextField
                                    label="Valor da variante"
                                    placeholder={`ex: ${variant.optionName === "Cor" ? "Preto" : variant.optionName === "Tamanho" ? "GG" : "Valor"}`}
                                    value={variant.optionValue}
                                    onChange={(v) => handleOptionValueChange(variant.id, v)}
                                    autoComplete="off"
                                    requiredIndicator
                                  />
                                </div>
                              </InlineStack>
                            </div>

                            {variants.length > 1 && (
                              <Button
                                icon={DeleteIcon}
                                onClick={() => removeVariant(variant.id)}
                                accessibilityLabel="Remover variante"
                              />
                            )}
                          </InlineStack>

                          {variant.products.length === 0 && (
                            <BlockStack gap="100" align="center">
                              <Text as="p" variant="headingSm">
                                Selecione as variantes de produto para esta opção
                              </Text>

                              <Button
                                variant="primary"
                                onClick={() => selectProducts(variant.id)}
                              >
                                Selecionar Variantes
                              </Button>
                            </BlockStack>
                          )}

                          {variant.products.length !== 0 && (
                            <BlockStack gap="100" align="center">
                              <InlineStack
                                gap="200"
                                blockAlign="end"
                                align="space-between"
                              >
                                <Text as="p" variant="headingSm">
                                  Variantes de produto nesta opção
                                </Text>

                                <Button
                                  variant="plain"
                                  onClick={() => selectProducts(variant.id)}
                                >
                                  Adicionar Mais Variantes
                                </Button>
                              </InlineStack>

                              <BlockStack gap="200" align="center">
                                {variant.products.map((product) => {
                                  const key = `${variant.id}-${product.id}`;
                                  return (
                                    <BlockStack gap="200" key={product.id}>
                                      <Divider />

                                      <InlineStack
                                        blockAlign="center"
                                        gap="500"
                                      >
                                        <Thumbnail
                                          source={
                                            product.productImage || ImageIcon
                                          }
                                          alt={product.productAlt}
                                        />

                                        <div style={{ flex: 1 }}>
                                          <Text
                                            as="span"
                                            variant="headingMd"
                                            fontWeight="semibold"
                                          >
                                            {product.productTitle}
                                          </Text>

                                          {product.options?.map((opt, i) => (
                                            <Text key={i} as="p" variant="bodySm">
                                              {opt.name} {opt.value}
                                            </Text>
                                          ))}

                                          {product.price && (
                                            <Text as="p" variant="bodySm">
                                              Preço: R$ {parseFloat(product.price).toFixed(2)}
                                            </Text>
                                          )}
                                        </div>

                                        <InlineStack
                                          gap="200"
                                          align="end"
                                          blockAlign="end"
                                        >
                                          <div style={{ flex: 1 }}>
                                            <TextField
                                              label="Quantidade"
                                              type="number"
                                              value={String(product.quantity)}
                                              onChange={(v) =>
                                                updateQuantity(
                                                  variant.id,
                                                  product.id,
                                                  Number(v)
                                                )
                                              }
                                              autoComplete="off"
                                              min={1}
                                            />
                                          </div>

                                          <Popover
                                            active={Boolean(popoverState[key])}
                                            activator={
                                              <Button
                                                disclosure
                                                onClick={() =>
                                                  togglePopover(key)
                                                }
                                              >
                                                Ações
                                              </Button>
                                            }
                                            onClose={() => togglePopover(key)}
                                          >
                                            <ActionList
                                              actionRole="menuitem"
                                              items={[
                                                {
                                                  content: "Remover",
                                                  icon: DeleteIcon,
                                                  onAction: () =>
                                                    removeProduct(
                                                      variant.id,
                                                      product.id
                                                    ),
                                                },
                                                {
                                                  content: "Duplicar",
                                                  icon: DuplicateIcon,
                                                  onAction: () =>
                                                    duplicateProduct(
                                                      variant.id,
                                                      product
                                                    ),
                                                },
                                              ]}
                                            />
                                          </Popover>
                                        </InlineStack>
                                      </InlineStack>
                                    </BlockStack>
                                  );
                                })}
                              </BlockStack>
                            </BlockStack>
                          )}
                        </BlockStack>
                      </Box>

                      {idx === variants.length - 1 && (
                        <Box>
                          <Divider />
                          <Box padding={"100"}>
                            <Button
                              icon={PlusCircleIcon}
                              variant="tertiary"
                              fullWidth={false}
                              onClick={addVariant}
                            >
                              Adicionar outra variante
                            </Button>
                          </Box>
                        </Box>
                      )}
                    </BlockStack>
                  ))}
                </Box>
              </BlockStack>
            </Card>

            <Card>
              <FormLayout>
                <Checkbox
                  label="Arredondar preço para valor promocional (ex: R$ 110,00 para R$ 109,99)"
                  checked={useMagicPrice}
                  onChange={(checked) => setUseMagicPrice(checked)}
                />
                <Text as="p" variant="bodySm" tone="subdued">
                  Quando ativado, o preço do pacote será arredondado para o valor promocional mais próximo.
                </Text>
              </FormLayout>
            </Card>

            {error && (
              <Banner
                title={error}
                tone="critical"
                onDismiss={() => setError(null)}
              />
            )}
          </BlockStack>
        </Layout.Section>
      </Layout>

      <PageActions
        primaryAction={{
          content: 'Criar Pacote',
          onAction: handleSave,
          disabled: isSubmitting,
        }}
      />
    </Page>
  );
}
